<section class="search content">
    <div class="search__content">
        <form class="search__form" action="/site/search" method="get" id="search">
            <input class="search__input" type="search" placeholder="Название, серия, автор, издательство" name="q">
            <button class="button search__submit" type="submit">Найти</button>
        </form>
        <a href="/lk" class="button lk-link js-lk">Личный кабинет</a>
    </div>
</section>